Homepage: https://SenlinOS.com

QJoyPad icon by: SenlinOS (森林OS) 

Icon license: CC0 
https://creativecommons.org/publicdomain/zero/1.0/

