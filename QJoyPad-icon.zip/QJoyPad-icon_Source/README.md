Homepage: https://SenlinOS.com

QJoyPad icon by: SenlinOS (森林OS)

Icon license: CC0
https://creativecommons.org/publicdomain/zero/1.0/



QJoyPad-icon.zip DL:

https://github.com/SenlinOS/databox/raw/master/QJoyPad-icon.zip



Change the tray icon (更改托盘图标)
Extract the zip package to your home directory (将zip包解压到主目录)

cd QJoyPad_icon

sudo cp * /usr/share/pixmaps/qjoypad

-------------------------------------

QJoyPad 4.3.1 的图标位置发生了改变，所以替换图标的方法也不同：

1. 将zip包中的 gamepad4-24x24.png 解压到用户主目录。
2. 将 gamepad4-24x24.png 重命名为：qjoypad.png
3. 在终端中使用命令：sudo cp qjoypad.png /usr/share/icons/hicolor/24x24/apps

这个是白色图标，如果你的系统栏是浅色的，你也可以选择黑色图标，重命名也为：qjoypad.png
