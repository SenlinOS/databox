Homepage: https://SenlinOS.com

QJoyPad icon by: SenlinOS (森林OS) 

Icon license: CC0
https://creativecommons.org/publicdomain/zero/1.0/



QJoyPad-icon.zip DL:

https://github.com/SenlinOS/databox/raw/master/QJoyPad-icon.zip



Change the tray icon (更改托盘图标)
Extract the zip package to your home directory (将zip包解压到主目录)

cd QJoyPad_icon

sudo cp * /usr/share/pixmaps/qjoypad