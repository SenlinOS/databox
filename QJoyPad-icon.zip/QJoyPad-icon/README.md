The Icons for QJoyPad 4.3.1 or Later.

1. Rename a PNG image you like.
	- Choose an Orange or White or Black PNG image
	- Copy it to the user home directory and rename it: qjoypad.png

2. Execute the following two commands in the terminal respectively:
	sudo cp qjoypad.png /usr/share/icons/hicolor/24x24/apps
	sudo cp qjoypad.png /usr/share/icons/hicolor/64x64/apps

The Icon replacement completed.

---

QJoyPad icon by: SenlinOS
Homepage: https://SenlinOS.com

Icon license: CC0
https://creativecommons.org/publicdomain/zero/1.0/


QJoyPad-icon.zip Download Link:
https://github.com/SenlinOS/databox/raw/master/QJoyPad-icon.zip