The Icons for QJoyPad 4.3.1 or Later.

1. Rename your favorite set of PNG images to: qjoypad.png
	- Orange or Light or Dark of the PNG images.
	- Copy 24 or 64 to the user home directory and rename each.

2. Execute commands at the terminal (Please correspond to the Icon size):
sudo cp qjoypad.png /usr/share/icons/hicolor/24x24/apps
&
sudo cp qjoypad.png /usr/share/icons/hicolor/64x64/apps

---

QJoyPad icon by: SenlinOS
Homepage: https://SenlinOS.com

Icon license: CC0
https://creativecommons.org/publicdomain/zero/1.0/


QJoyPad-icon.zip DL:
https://github.com/SenlinOS/databox/raw/master/QJoyPad-icon.zip