图标为 QJoyPad 4.3.1 或更新版本.

1. 将你喜欢的一组PNG图像重命名为：qjoypad.png
	- 橙色或浅色或深色的PNG图像。
	- 将24或64复制到用户主目录中，并分别重命名。

2. 在终端执行命令：
sudo cp qjoypad.png /usr/share/icons/hicolor/24x24/apps
与
sudo cp qjoypad.png /usr/share/icons/hicolor/64x64/apps

(请对应图像尺寸)

---

QJoyPad 图标作者: 森林OS (SenlinOS)
主页: https://SenlinOS.com

图标许可者: CC0，公共领域，可以自由使用。
https://creativecommons.org/publicdomain/zero/1.0/


QJoyPad-icon.zip 下载地址:
https://share.weiyun.com/3bYBIRut
或
https://github.com/SenlinOS/databox/raw/master/QJoyPad-icon.zip